package com.de.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.de.R;
import com.de.data.CsvManager;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_PERMS   = 101;
    private static final int REQ_STORAGE = 102;
    private static final int REQ_CAM1    = 201;
    private static final int REQ_CAM2    = 202;

    private Button    btnMR, btnDC, btnEL, btnWT;
    private TextView  lblActivitySelected, lblMeterSelected;
    private EditText  txtMeterNum, txtMeterReading, txtComments;
    private Button    btnCapture1, btnCapture2;
    private TextView  lblStatus1, lblStatus2, lblProcessing, lblLog;
    private ImageView imgPreview1, imgPreview2;
    private Button    btnDeletePhotos, btnSave, btnDownload, btnViewShare;

    private String activity = "", meterType = "";
    private String img1Name = "", img2Name = "";
    private String img1Stamped = "", img2Stamped = "";
    private String img1Date = "", img1Time = "";
    private int    entryCount = 0;
    private File   tempCamFile;
    private CsvManager csv;
    private String userName = "";
    private static final String PREFS_NAME = "ReadEntryPrefs";
    private static final String KEY_USERNAME = "user_name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        csv = new CsvManager(this);
        loadLogo();
        bindViews();
        setupListeners();
        checkPermissions();
        loadPersistentStatus();
        loadUserName();
        checkFirstLaunchName();
    }

    private void loadUserName() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        userName = prefs.getString(KEY_USERNAME, "");
    }

    // Show one-time name prompt on first app launch after install
    private void checkFirstLaunchName() {
        if (userName.isEmpty()) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            showNamePrompt(prefs);
        }
    }

    private void showNamePrompt(SharedPreferences prefs) {
        final EditText input = new EditText(this);
        input.setHint("Enter your name");
        input.setTextColor(Color.BLACK);
        input.setHintTextColor(0xFF888888);
        input.setPadding(40, 30, 40, 30);

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Welcome to Read Entry")
            .setMessage("Please enter your name. This will be used to label your reports and is only required once.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Continue", null)
            .create();

        dialog.setOnShowListener(d -> {
            Button btn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            btn.setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) {
                    input.setError("Name is required");
                    return;
                }
                // Sanitize for filename use
                String safeName = name.replaceAll("[^a-zA-Z0-9 ]", "").trim().replaceAll("\\s+", "_");
                if (safeName.isEmpty()) safeName = "User";
                prefs.edit().putString(KEY_USERNAME, safeName).apply();
                userName = safeName;
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    // Load saved entry count and photo count on restart
    private void loadPersistentStatus() {
        // Count existing CSV rows
        File csvFile = csv.getCsvFile();
        if (csvFile != null && csvFile.exists()) {
            try (java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(csvFile))) {
                int count = 0;
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.startsWith("Activity") && !line.trim().isEmpty()) count++;
                }
                entryCount = count;
                if (count > 0) {
                    lblLog.setText("✓ " + count + " saved entries ready  •  "
                        + csv.getPhotoPaths().size() + " photos available");
                    lblLog.setTextColor(0xFF34C759);
                }
            } catch (Exception ignored) {}
        }

        // Show photo count
        List<String> photos = csv.getPhotoPaths();
        if (!photos.isEmpty()) {
            lblProcessing.setText("✓ " + photos.size() + " photos saved — tap View & Share to forward");
            lblProcessing.setTextColor(0xFF007AFF);
        }
    }

    private void loadLogo() {
        try {
            ImageView imgLogo = findViewById(R.id.imgLogo);
            if (imgLogo != null) {
                android.graphics.drawable.Drawable d =
                    android.graphics.drawable.Drawable.createFromStream(
                        getAssets().open("logo.png"), "logo");
                imgLogo.setImageDrawable(d);
            }
        } catch (Exception ignored) {}
    }

    private void bindViews() {
        btnMR               = findViewById(R.id.btnMR);
        btnDC               = findViewById(R.id.btnDC);
        btnEL               = findViewById(R.id.btnEL);
        btnWT               = findViewById(R.id.btnWT);
        lblActivitySelected = findViewById(R.id.lblActivitySelected);
        lblMeterSelected    = findViewById(R.id.lblMeterSelected);
        txtMeterNum         = findViewById(R.id.txtMeterNum);
        txtMeterReading     = findViewById(R.id.txtMeterReading);
        txtComments         = findViewById(R.id.txtComments);
        btnCapture1         = findViewById(R.id.btnCapture1);
        btnCapture2         = findViewById(R.id.btnCapture2);
        lblStatus1          = findViewById(R.id.lblStatus1);
        lblStatus2          = findViewById(R.id.lblStatus2);
        lblProcessing       = findViewById(R.id.lblProcessing);
        lblLog              = findViewById(R.id.lblLog);
        imgPreview1         = findViewById(R.id.imgPreview1);
        imgPreview2         = findViewById(R.id.imgPreview2);
        btnDeletePhotos     = findViewById(R.id.btnDeletePhotos);
        btnSave             = findViewById(R.id.btnSave);
        btnDownload         = findViewById(R.id.btnDownload);
        btnViewShare        = findViewById(R.id.btnViewShare);
    }

    private void setupListeners() {
        btnMR.setOnClickListener(v -> selectActivity("Meter Reading", btnMR, btnDC));
        btnDC.setOnClickListener(v -> selectActivity("Disconnection", btnDC, btnMR));
        btnEL.setOnClickListener(v -> selectMeter("EL", btnEL, btnWT));
        btnWT.setOnClickListener(v -> selectMeter("WT", btnWT, btnEL));
        btnCapture1.setOnClickListener(v -> launchCamera(REQ_CAM1));
        btnCapture2.setOnClickListener(v -> launchCamera(REQ_CAM2));
        btnDeletePhotos.setOnClickListener(v -> showDeleteWarning());
        btnSave.setOnClickListener(v      -> saveEntry());
        btnDownload.setOnClickListener(v  -> shareCsv());
        btnViewShare.setOnClickListener(v -> viewAndShare());
    }

    private void selectActivity(String val, Button on, Button off) {
        activity = val;
        on.setBackgroundResource(R.drawable.segment_btn_selected);
        on.setTextColor(0xFF007AFF);
        off.setBackgroundResource(R.drawable.segment_btn_unselected);
        off.setTextColor(0xFF8E8E93);
        lblActivitySelected.setText("✓ Selected: " + val);
        lblActivitySelected.setTextColor(0xFF34C759);
    }

    private void selectMeter(String val, Button on, Button off) {
        meterType = val;
        on.setBackgroundResource(R.drawable.segment_btn_selected);
        on.setTextColor(0xFF007AFF);
        off.setBackgroundResource(R.drawable.segment_btn_unselected);
        off.setTextColor(0xFF8E8E93);
        lblMeterSelected.setText("✓ Selected: " + val);
        lblMeterSelected.setTextColor(0xFF34C759);
    }

    private void launchCamera(int req) {
        try {
            tempCamFile = File.createTempFile("CAM_", ".jpg",
                getExternalFilesDir(Environment.DIRECTORY_PICTURES));
            Uri uri = FileProvider.getUriForFile(this, "com.de.fileprovider", tempCamFile);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            startActivityForResult(intent, req);
        } catch (Exception e) {
            toast("Camera error: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (result != RESULT_OK || (req != REQ_CAM1 && req != REQ_CAM2)) {
            // Clean up temp file if capture was cancelled
            if (tempCamFile != null && tempCamFile.exists()) tempCamFile.delete();
            return;
        }
        String mNum  = txtMeterNum.getText().toString().trim();
        String date  = new SimpleDateFormat("dd-MMM-yyyy", Locale.US).format(new Date());
        String time  = new SimpleDateFormat("hh:mm:ss aa", Locale.US).format(new Date());
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String name  = meterType + "_" + mNum + (req == REQ_CAM1 ? "_img1_" : "_img2_") + stamp + ".jpg";
        File rawFile   = tempCamFile;
        String raw     = rawFile.getAbsolutePath();
        String stamped = stampImage(raw, name, date, time);

        // Delete the original large temp capture now that the compressed,
        // renamed version has been written — only one file remains per photo
        if (rawFile.exists() && !rawFile.getAbsolutePath().equals(stamped)) {
            rawFile.delete();
        }

        if (req == REQ_CAM1) {
            img1Stamped = stamped; img1Name = name;
            img1Date = date; img1Time = time;
            lblStatus1.setText("Image 1 saved: " + name);
            lblStatus1.setTextColor(0xFF34C759);
            if (!stamped.isEmpty()) imgPreview1.setImageBitmap(BitmapFactory.decodeFile(stamped));
            csv.appendPhoto(stamped);
        } else {
            img2Stamped = stamped; img2Name = name;
            lblStatus2.setText("Image 2 saved: " + name);
            lblStatus2.setTextColor(0xFF34C759);
            if (!stamped.isEmpty()) imgPreview2.setImageBitmap(BitmapFactory.decodeFile(stamped));
            csv.appendPhoto(stamped);
        }
        lblProcessing.setText("Image stamped and saved.");
    }

    private static final int TARGET_MAX_BYTES = 100 * 1024; // 100 KB target
    private static final int MAX_DIMENSION    = 1100;       // downscale long side to this

    private String stampImage(String src, String name, String date, String time) {
        try {
            // Step 1: decode with downsampling to avoid huge memory use
            Bitmap bmp = decodeScaledBitmap(src, MAX_DIMENSION);
            if (bmp == null) return src;

            // Step 2: correct orientation based on EXIF tag from original file
            int rotation = readExifRotation(src);
            if (rotation != 0) {
                Bitmap rotated = rotateBitmap(bmp, rotation);
                if (rotated != bmp) { bmp.recycle(); bmp = rotated; }
            }

            Bitmap mut = bmp.copy(Bitmap.Config.ARGB_8888, true);
            Canvas c   = new Canvas(mut);
            Paint  p   = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.WHITE);
            p.setTextSize(mut.getWidth() * 0.035f);
            p.setShadowLayer(6, 2, 2, Color.BLACK);
            float x = mut.getWidth() * 0.42f;
            float y = mut.getHeight() * 0.05f;
            c.drawText(date, x, y, p);
            c.drawText(time, x, y + p.getTextSize() * 1.4f, p);

            File out = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), name);
            compressToTargetSize(mut, out, TARGET_MAX_BYTES);
            return out.getAbsolutePath();
        } catch (Exception e) { return src; }
    }

    // Read EXIF orientation tag and return degrees to rotate to display upright
    private int readExifRotation(String path) {
        try {
            androidx.exifinterface.media.ExifInterface exif =
                new androidx.exifinterface.media.ExifInterface(path);
            int orientation = exif.getAttributeInt(
                androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90:  return 90;
                case androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180: return 180;
                case androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270: return 270;
                default: return 0;
            }
        } catch (Exception e) { return 0; }
    }

    private Bitmap rotateBitmap(Bitmap bmp, int degrees) {
        if (degrees == 0) return bmp;
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), matrix, true);
    }

    // Decode a bitmap downsampled so its longest side is at most maxDim, preserving aspect ratio
    private Bitmap decodeScaledBitmap(String path, int maxDim) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        int w = bounds.outWidth, h = bounds.outHeight;
        if (w <= 0 || h <= 0) return BitmapFactory.decodeFile(path);

        int sample = 1;
        int longSide = Math.max(w, h);
        while (longSide / (sample * 2) >= maxDim) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap decoded = BitmapFactory.decodeFile(path, opts);
        if (decoded == null) return null;

        // Final precise resize if still above maxDim on the long side
        int dw = decoded.getWidth(), dh = decoded.getHeight();
        float scale = Math.min(1f, (float) maxDim / Math.max(dw, dh));
        if (scale < 1f) {
            int nw = Math.max(1, Math.round(dw * scale));
            int nh = Math.max(1, Math.round(dh * scale));
            Bitmap resized = Bitmap.createScaledBitmap(decoded, nw, nh, true);
            if (resized != decoded) decoded.recycle();
            return resized;
        }
        return decoded;
    }

    // Iteratively reduce JPEG quality (and dimensions if needed) until under targetBytes
    private void compressToTargetSize(Bitmap bmp, File out, int targetBytes) throws Exception {
        int quality = 88;
        Bitmap working = bmp;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        while (true) {
            baos.reset();
            working.compress(Bitmap.CompressFormat.JPEG, quality, baos);
            if (baos.size() <= targetBytes || quality <= 55) break;
            quality -= 7;
        }

        // If still too large at lowest acceptable quality, shrink dimensions further
        // Floor kept high (700px) so meter digits stay legible
        while (baos.size() > targetBytes && Math.max(working.getWidth(), working.getHeight()) > 700) {
            int nw = Math.round(working.getWidth() * 0.9f);
            int nh = Math.round(working.getHeight() * 0.9f);
            Bitmap smaller = Bitmap.createScaledBitmap(working, nw, nh, true);
            if (smaller != working && working != bmp) working.recycle();
            working = smaller;
            quality = 75;
            baos.reset();
            working.compress(Bitmap.CompressFormat.JPEG, quality, baos);
        }

        try (FileOutputStream fos = new FileOutputStream(out)) {
            fos.write(baos.toByteArray());
        }
    }

    private void showDeleteWarning() {
        new AlertDialog.Builder(this)
            .setTitle("⚠ Warning")
            .setMessage("Photos Should Be Shared Before Deleting\n\nClick \"OK\" to proceed and \"Cancel\" to return to previous screen.")
            .setCancelable(false)
            .setPositiveButton("OK", (d, w) -> deletePhotos())
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void deletePhotos() {
        List<String> photos = csv.getPhotoPaths();
        if (photos.isEmpty()) {
            toast("No photos found.");
            return;
        }
        String[]  names   = new String[photos.size()];
        boolean[] checked = new boolean[photos.size()];
        for (int i = 0; i < photos.size(); i++)
            names[i] = new File(photos.get(i)).getName();

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("🗑 Delete Photos")
            .setMultiChoiceItems(names, checked,
                (d, which, isChecked) -> checked[which] = isChecked)
            .setPositiveButton("Delete Selected", (d, w) -> confirmDelete(photos, checked))
            .setNeutralButton("✓ Select All", null)
            .setNegativeButton("Cancel", null)
            .create();

        dialog.setOnShowListener(dlg -> {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                ListView lv = dialog.getListView();
                for (int i = 0; i < names.length; i++) {
                    checked[i] = true;
                    lv.setItemChecked(i, true);
                }
            });
            // Style delete button red
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(0xFFFF3B30);
        });
        dialog.show();
    }

    private void confirmDelete(List<String> photos, boolean[] checked) {
        List<String> toDelete = new ArrayList<>();
        for (int i = 0; i < photos.size(); i++)
            if (checked[i]) toDelete.add(photos.get(i));

        if (toDelete.isEmpty()) { toast("No photos selected."); return; }

        new AlertDialog.Builder(this)
            .setTitle("Confirm Delete")
            .setMessage("Permanently delete " + toDelete.size() + " photo(s)? This cannot be undone.")
            .setPositiveButton("Delete", (d, w) -> {
                int deleted = 0;
                for (String path : toDelete) {
                    File f = new File(path);
                    if (f.exists() && f.delete()) deleted++;
                }
                // Rebuild photos.txt without deleted files
                rebuildPhotoIndex(photos, toDelete);
                toast(deleted + " photo(s) deleted permanently.");
                lblLog.setText("Deleted " + deleted + " photo(s).");
                lblLog.setTextColor(0xFFFF3B30);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void rebuildPhotoIndex(List<String> allPhotos, List<String> deleted) {
        File photoFile = csv.getPhotoFile();
        try (java.io.FileWriter fw = new java.io.FileWriter(photoFile, false)) {
            for (String path : allPhotos) {
                if (!deleted.contains(path)) {
                    fw.write(path + "\n");
                }
            }
        } catch (Exception ignored) {}
    }

    private void saveEntry() {
        String mNum = txtMeterNum.getText().toString().trim();
        if (activity.isEmpty() || meterType.isEmpty() || mNum.isEmpty()) {
            toast("Please select Activity, Meter Type and enter Meter Number.");
            return;
        }
        csv.appendRow(activity + "," + meterType + "," + mNum + ","
            + txtMeterReading.getText().toString().trim() + ","
            + txtComments.getText().toString().trim() + ","
            + img1Name + "," + img2Name + "," + img1Date + " " + img1Time);
        entryCount++;
        lblLog.setText("✓ Saved entry #" + entryCount
            + "  •  " + csv.getPhotoPaths().size() + " photos available");
        lblLog.setTextColor(0xFF34C759);
        resetForm();
    }

    private void shareCsv() {
        if (entryCount == 0) { toast("No entries yet."); return; }
        File f = csv.getCsvFile();
        if (f == null || !f.exists()) { toast("CSV file not found."); return; }
        try {
            String namePrefix = userName.isEmpty() ? "" : userName + "_";
            String shareName  = namePrefix + "DE_data.csv";
            File shareDir = new File(getExternalFilesDir(null), "share_out");
            if (!shareDir.exists()) shareDir.mkdirs();
            File dest = new File(shareDir, shareName);
            copyFile(f, dest);

            Uri uri = FileProvider.getUriForFile(this, "com.de.fileprovider", dest);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/csv");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.putExtra(Intent.EXTRA_SUBJECT, shareName);
            android.content.ClipData clip =
                android.content.ClipData.newUri(getContentResolver(), shareName, uri);
            i.setClipData(clip);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Share CSV via"));
        } catch (Exception e) {
            toast("Share failed: " + e.getMessage());
        }
    }

    private void copyFile(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
        }
    }

    private void viewAndShare() {
        List<String> photos = csv.getPhotoPaths();
        if (photos.isEmpty()) { toast("No photos saved yet."); return; }
        String[]  names   = new String[photos.size()];
        boolean[] checked = new boolean[photos.size()];
        for (int i = 0; i < photos.size(); i++)
            names[i] = new File(photos.get(i)).getName();
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Select Photos to Share")
            .setMultiChoiceItems(names, checked,
                (d, which, isChecked) -> checked[which] = isChecked)
            .setPositiveButton("\u2192 Forward", (d, w) -> forwardPhotos(photos, checked))
            .setNeutralButton("\u2713 Select All", null)
            .setNegativeButton("Cancel", null)
            .create();
        dialog.setOnShowListener(dlg ->
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                ListView lv = dialog.getListView();
                for (int i = 0; i < names.length; i++) {
                    checked[i] = true;
                    lv.setItemChecked(i, true);
                }
            }));
        dialog.show();
    }

    private static final long MAX_ZIP_BYTES = 80L * 1024 * 1024; // 80 MB per ZIP

    private void forwardPhotos(List<String> photos, boolean[] checked) {
        List<File> sel = new ArrayList<>();
        for (int i = 0; i < photos.size(); i++) {
            if (!checked[i]) continue;
            File f = new File(photos.get(i));
            if (f.exists()) sel.add(f);
        }
        if (sel.isEmpty()) { toast("No photos selected."); return; }

        long totalBytes = 0;
        for (File f : sel) totalBytes += f.length();
        int estimatedParts = (int) Math.max(1, Math.ceil((double) totalBytes / MAX_ZIP_BYTES));

        if (estimatedParts > 1)
            toast("Compressing " + sel.size() + " photo(s) into " + estimatedParts + " ZIP files...");
        else
            toast("Compressing " + sel.size() + " photo(s)...");

        new Thread(() -> {
            try {
                String stamp      = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String namePrefix = userName.isEmpty() ? "" : userName + "_";
                File shareDir      = new File(getExternalFilesDir(null), "share_out");
                if (!shareDir.exists()) shareDir.mkdirs();

                // Bin files into groups that each stay under MAX_ZIP_BYTES
                List<List<File>> bins = new ArrayList<>();
                List<File> currentBin = new ArrayList<>();
                long currentBinSize = 0;
                for (File f : sel) {
                    long size = f.length();
                    // If a single file alone exceeds the limit, it still gets its own bin
                    if (!currentBin.isEmpty() && currentBinSize + size > MAX_ZIP_BYTES) {
                        bins.add(currentBin);
                        currentBin = new ArrayList<>();
                        currentBinSize = 0;
                    }
                    currentBin.add(f);
                    currentBinSize += size;
                }
                if (!currentBin.isEmpty()) bins.add(currentBin);

                int totalParts = bins.size();
                List<Uri> zipUris  = new ArrayList<>();
                List<String> zipNames = new ArrayList<>();

                for (int partIdx = 0; partIdx < bins.size(); partIdx++) {
                    List<File> bin = bins.get(partIdx);
                    String partSuffix = totalParts > 1
                        ? "_part" + (partIdx + 1) + "of" + totalParts
                        : "";
                    String zipName = namePrefix + "DE_meters_" + stamp + partSuffix + ".zip";
                    File zipFile = new File(shareDir, zipName);

                    java.util.zip.ZipOutputStream zos =
                        new java.util.zip.ZipOutputStream(
                            new BufferedOutputStream(new FileOutputStream(zipFile)));
                    for (File f : bin) {
                        zos.putNextEntry(new java.util.zip.ZipEntry(f.getName()));
                        try (InputStream in = new FileInputStream(f)) {
                            byte[] buf = new byte[8192];
                            int len;
                            while ((len = in.read(buf)) > 0) zos.write(buf, 0, len);
                        }
                        zos.closeEntry();
                    }
                    zos.finish();
                    zos.close();

                    Uri uri = FileProvider.getUriForFile(this, "com.de.fileprovider", zipFile);
                    zipUris.add(uri);
                    zipNames.add(zipName);
                }

                runOnUiThread(() -> {
                    try {
                        Intent share;
                        if (zipUris.size() == 1) {
                            share = new Intent(Intent.ACTION_SEND);
                            share.setType("application/zip");
                            share.putExtra(Intent.EXTRA_STREAM, zipUris.get(0));
                            share.putExtra(Intent.EXTRA_SUBJECT, zipNames.get(0));
                            android.content.ClipData clip = android.content.ClipData.newUri(
                                getContentResolver(), zipNames.get(0), zipUris.get(0));
                            share.setClipData(clip);
                        } else {
                            share = new Intent(Intent.ACTION_SEND_MULTIPLE);
                            share.setType("application/zip");
                            ArrayList<Uri> uriList = new ArrayList<>(zipUris);
                            share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uriList);
                            android.content.ClipData clip = android.content.ClipData.newUri(
                                getContentResolver(), zipNames.get(0), zipUris.get(0));
                            for (int i = 1; i < zipUris.size(); i++)
                                clip.addItem(new android.content.ClipData.Item(zipUris.get(i)));
                            share.setClipData(clip);
                            toast(zipUris.size() + " ZIP files created (split by size)");
                        }
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(share, "Forward via"));
                    } catch (Exception e) { toast("Share failed: " + e.getMessage()); }
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("Zip failed: " + e.getMessage()));
            }
        }).start();
    }

    private void resetForm() {
        activity = ""; meterType = "";
        img1Name = ""; img2Name = "";
        img1Stamped = ""; img2Stamped = "";
        img1Date = ""; img1Time = "";
        txtMeterNum.setText(""); txtMeterReading.setText(""); txtComments.setText("");
        imgPreview1.setImageDrawable(null); imgPreview2.setImageDrawable(null);
        lblActivitySelected.setText("None selected"); lblActivitySelected.setTextColor(0xFFFF3B30);
        lblMeterSelected.setText("None selected");    lblMeterSelected.setTextColor(0xFFFF3B30);
        lblStatus1.setText("Image 1: Not captured");  lblStatus1.setTextColor(0xFFFF3B30);
        lblStatus2.setText("Image 2: Not captured");  lblStatus2.setTextColor(0xFFFF3B30);
        lblProcessing.setText("");
        for (Button b : new Button[]{btnMR, btnDC, btnEL, btnWT}) {
            b.setBackgroundResource(R.drawable.segment_btn_unselected);
            b.setTextColor(0xFF8E8E93);
        }
    }

    private void checkPermissions() {
        List<String> needed = new ArrayList<>();
        needed.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.READ_MEDIA_IMAGES);
            needed.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q)
                needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        List<String> req = new ArrayList<>();
        for (String perm : needed)
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED)
                req.add(perm);
        if (!req.isEmpty())
            ActivityCompat.requestPermissions(this, req.toArray(new String[0]), REQ_PERMS);
        else
            promptManageStorage();
    }

    private void promptManageStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                && !Environment.isExternalStorageManager()) {
            new AlertDialog.Builder(this)
                .setTitle("All Files Access")
                .setMessage("Grant Manage All Files permission for full storage access.")
                .setPositiveButton("Grant", (d, w) -> startActivityForResult(
                    new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())), REQ_STORAGE))
                .setNegativeButton("Skip", null).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] g) {
        super.onRequestPermissionsResult(req, p, g);
        if (req == REQ_PERMS) promptManageStorage();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
