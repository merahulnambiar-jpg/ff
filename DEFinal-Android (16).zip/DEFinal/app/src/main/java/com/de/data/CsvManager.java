package com.de.data;

import android.content.Context;
import android.os.Environment;
import java.io.*;
import java.util.*;

public class CsvManager {
    private static final String CSV_FILE   = "DE_data.csv";
    private static final String PHOTO_FILE = "photos.txt";
    private static final String HEADER     = "Activity,MeterType,MeterNumber,MeterReading,Comments,Image1,Image2,DateCaptured\n";

    private final File csvFile;
    private final File photoFile;

    public CsvManager(Context ctx) {
        File dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (dir != null && !dir.exists()) dir.mkdirs();
        csvFile   = new File(dir, CSV_FILE);
        photoFile = new File(dir, PHOTO_FILE);
        if (!csvFile.exists()) write(csvFile, HEADER, false);
    }

    public void appendRow(String row)   { write(csvFile,   row + "\n", true); }
    public void appendPhoto(String path){ if (path != null && !path.isEmpty()) write(photoFile, path + "\n", true); }

    public List<String> getPhotoPaths() {
        List<String> list = new ArrayList<>();
        if (!photoFile.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(photoFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && new File(line).exists()) list.add(line);
            }
        } catch (Exception ignored) {}
        return list;
    }

    public File getCsvFile()   { return csvFile; }
    public File getPhotoFile() { return photoFile; }

    private void write(File f, String text, boolean append) {
        try (FileWriter fw = new FileWriter(f, append)) { fw.write(text); }
        catch (Exception ignored) {}
    }
}
